#ifndef BASE_H_
#define BASE_H_
class Base {
public:
   virtual void f3( );
   virtual void f4( );
   virtual void f5( );
   virtual void foo0( );
   virtual void foo1( );
   virtual void foo2( );
private:
   virtual void f0( );
   virtual void f1( );
   virtual void f2( );
};
#endif /* BASE_H_ */
