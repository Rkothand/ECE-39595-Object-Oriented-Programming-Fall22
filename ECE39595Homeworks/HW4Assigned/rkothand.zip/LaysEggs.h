#ifndef _EGGS_H
#define _EGGS_H
#include <iostream>

class LaysEggs{
    public:
    virtual void layEggs()=0;
};

#endif