#include "FlyPoorly.h"
#include <iostream>

void FlyPoorly::fly(){
    std::cout<<"Flys poorly" <<std::endl;
}