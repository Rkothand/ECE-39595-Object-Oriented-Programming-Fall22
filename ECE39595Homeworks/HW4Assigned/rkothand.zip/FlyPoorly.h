#ifndef FLYPOORLY_H_
#define FLYPOORLY_H_
#include "FlyBehavior.h"

class FlyPoorly : public FlyBehavior{
    public:
        void fly();

};
#endif 

